function load(){
  let data = JSON.parse(localStorage.getItem("notices") || "[]");
  let box = document.getElementById("notices");
  box.innerHTML = "";
  data.reverse().forEach(n=>{
    box.innerHTML += `
      <div class="notice">
        <h3>${n.title}</h3>
        <p>${n.desc}</p>
        <small>${n.date}</small>
      </div>
    `;
  });
}

function addNotice(){
  let title = document.getElementById("title").value;
  let desc = document.getElementById("desc").value;
  if(!title || !desc) return;

  let data = JSON.parse(localStorage.getItem("notices") || "[]");
  data.push({
    title, desc,
    date: new Date().toLocaleDateString()
  });

  localStorage.setItem("notices", JSON.stringify(data));
  document.getElementById("title").value="";
  document.getElementById("desc").value="";
  load();
}

load();
